Thanks for downloading Pizza! This version only supports the new Custom Battle Mode. I hope you enjoy.

How to open Custom Battle Mode:
After typing in your in-game name, goto extras. Then, you will see the Custom Battle button, click on it, and you will be making your Custom Battle!